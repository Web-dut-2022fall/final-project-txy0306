from django.shortcuts import render,HttpResponse,redirect,reverse
from django.shortcuts import render,HttpResponse
from .models import Account

# Create your views here.

def login(request):

    if request.method == 'POST':
        print("进入页面")
        name = request.POST['username']
        password = request.POST['password']
        corr_email = Account.objects.filter(name=name).first()
        print(corr_email.name,corr_email.password)
        print("获取到信息")
        if name == corr_email.name and password == corr_email.password:
            print('登录成功')
            return HttpResponse('登录成功')

    return render(request,'log_in.html')



def logon(request):
    return HttpResponse('注册页面')

def logout(request):
    return HttpResponse('退出')

def index(request):
    print("进入index")
    return redirect(reverse('login'))
